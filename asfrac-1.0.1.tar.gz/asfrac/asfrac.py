#!/usr/bin/python3

from __future__ import print_function, division
from sys import argv, stderr

__version__ = "1.0.1"

def to_frac(num, max = 1001):
    for i in range(1, max):
        for ii in range(1, max):
            if (i / ii == num):
                return i, ii
    return False

if (__name__ == "__main__"):
    try:
        num = float(argv[1])
    except IndexError:
        print("usage: asfrac <number>", file = stderr)
        exit(1)
    except ValueError:
        print("usage: asfrac <number>", file = stderr)
        exit(1)

    if ("function" not in repr(to_frac)):
        exit(1)

    try:
        num1, num2 = to_frac(num)
    except TypeError:
        print("error: cannot compute result", file = stderr)
        exit(1)
        
    print(str(num) + " as a fraction is " +\
            str(num1) + "/" + str(num2))
    exit(0)
